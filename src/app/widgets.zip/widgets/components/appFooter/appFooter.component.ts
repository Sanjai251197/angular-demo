import { Component } from "@angular/core";
@Component({
    selector: 'appFooter-component',
    templateUrl: './appFooter.component.html'

})
export class AppFooterComponent{

}