import { Component } from "@angular/core";
@Component({
    selector: 'appBanner-component',
    templateUrl: './appBanner.component.html'

})
export class AppBannerComponent{

}