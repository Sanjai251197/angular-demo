import { NgModule } from "@angular/core";
import { AppBannerComponent } from "./components/appBanner/appBanner.component";
import { AppFooterComponent } from "./components/appFooter/appFooter.component";

@NgModule({
    declarations:[AppFooterComponent,AppBannerComponent],
    exports: [AppFooterComponent,AppBannerComponent]
})

export class WidgetsModule{

}